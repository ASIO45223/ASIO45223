%Using the fouth-Order Runge-Kutta method with h=o.1 to estimate y(0.2),
%given dy/dx = x + y and y(0) = 1.
function y = fouthrungeKutta()
clc;
clear;
%Define the differential equation 
f = @(x,y) x + y;
%Initial values
x = 0;
y = 1;
%Step size 
h = 0.1;
%Final value of x 
xf = 0.2;
%Calculating number of steps
n = round((xf - x)/h);
for i = 1:n 
    % Calculate K1,k2,k3,k4,new y and new X
    k1 = h*f(x,y);
    k2 = h*f(x + h/2, y + k1/2);
    k3 = h*f(x + h/2,y + k2/2);
    k4 = h*f(x + h, y + k3);
    y = y + (k1 + 2*k2 + 2*k3 + k4)/6;
    x = x + h;
    %Display results
    fprintf('Step %d: x = %.2f,y = %.6f\n',i,x,y);
end 
%Display final answer
fprintf('\ny(%.2f) = %.6f\n',xf,y);

end
