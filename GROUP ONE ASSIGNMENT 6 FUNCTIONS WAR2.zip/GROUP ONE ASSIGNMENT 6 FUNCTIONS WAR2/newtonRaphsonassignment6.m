%Newton Raphson method to find a root of the equation f(x) = x^3 - x -2 =
%0 withthe inital guess x0 = 1.5. using a tolerance of 0.00001 and a
%maximum of 20 iterations
function root = newtonRaphson()
clc;
clear;
%Defining function
f = @(x) x^3 - x - 2;
%defining derivative 
df =@(x) 3*x^2 -1;
%Initial guess 
x0 = 1.5;
%tolerance 
tol = 0.000001;
%Maximum number of iterations 
maxIter = 20;
for i=1:maxIter
    %Calculate f(x) and f'(x)
    fx = f(x0)
    dfx = df(x0);
    %Check if derivative is zero 
    if dfx == 0 
        error('Derivative is zero.Method cannot continue.');
    end
    %Newton Raphson formular
    x1 = x0 - fx/dfx;
    %Calculating error 
    error = abs(x1 -x0);
    %displaying iteration
    fprintf('Iteration %d: x = %.10f, Error = %.10f\n',i,x1,error);
    %check convergence 
    if error < tol
        root = x1; 
        fprintf('\nRoot = %.10f\n',root);
        fprintf('Number of iterations = %d/n',i);
        return;
    end
    %update x
    x0 = x1;
end 
%if convergence was not achieved 
root = x1 ;
fprintf('\nMaximum iterations reached.\n');
fprint('Approximate root = %.10f\n',root);

end