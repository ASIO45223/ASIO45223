%Number 1 .secant method of finding a root of f(x) =x*2 - x - 2 ,using x0=1
%and x1 = 2 ,continue untill 4 decimal places
function root = secantMethod()
clc;
clear;
%Define the function
f = @(x) x^2 - x-2;
%Initial values
x0 = 1;
x1 = 2;
%Tolerance
tol = 0.00005;
while true
    %function values 
    f0 = f(x0);
    f1 = f(x1);
    %calculated value
     x2 = x1 - (f1*(x1 - x0))/(f1 - f0);
    %calculated error
    error = abs(x2-x1);
    %displaying results
    fprintf('Iteration %d: x=%.6f,Error = %.6f\n',i,x2,error);
    %check convergence
    if error < tol
        root = x2;
        fprintf('\nRoot = %.6f\n',root);
        return;
    end
    %Update vaues
    x0 = x1;
    x1 = x2;
end

end