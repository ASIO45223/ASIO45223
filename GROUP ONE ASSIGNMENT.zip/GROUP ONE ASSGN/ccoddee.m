
clc;
clear;
close all;
 
% 1. Define the objective function
objective = @(Q) 2*Q(1)^2 + 3*Q(2)^2;
 
% 2. Convert the demand constraint to A*Q <= b
% Q1 + Q2 >= 10  becomes  -Q1 - Q2 <= -10
A = [-1 -1];
b = -10;
 
% 3. Define lower and upper bounds
lb = [2 1];
ub = [8 7];
 
% 4. Choose an initial feasible solution
Q0 = [5 5];
 
% 5. Set optimisation options
options = optimoptions('fmincon','Algorithm', 'sqp','Display', 'iter');
 
% 6. Solve the optimisation problem
[Q_opt, Z_min, exitflag, output] = fmincon(objective, Q0, A, b, [], [], lb, ub, [], options);
 
% 7. Display the results
fprintf('\nQUESTION 1: RESERVOIR WATER ALLOCATION\n');
fprintf('Optimal release from Reservoir A (Q1) = %.4f million m^3/day\n', Q_opt(1));
fprintf('Optimal release from Reservoir B (Q2) = %.4f million m^3/day\n', Q_opt(2));
fprintf('Total water supplied = %.4f million m^3/day\n', sum(Q_opt));
fprintf('Minimum operating cost = %.4f cost units\n', Z_min);
fprintf('Solver exit flag = %d\n', exitflag);
 
% 8. Generate a contour plot of the objective function
[Q1, Q2] = meshgrid(2:0.05:8, 1:0.05:7);
Z = 2*Q1.^2 + 3*Q2.^2;

figure;
contourf(Q1, Q2, Z, 25);
colorbar;
hold on;
 
% Demand boundary: Q1 + Q2 = 10
q1_line = linspace(2, 8, 200);
q2_line = 10 - q1_line;
valid = q2_line >= 1 & q2_line <= 7;
plot(q1_line(valid), q2_line(valid), 'r--', 'LineWidth', 2);
 
% Mark the optimal solution
plot(Q_opt(1), Q_opt(2),'kp','MarkerSize', 13, 'MarkerFaceColor', 'y');
 
xlabel('Reservoir A release, Q1 (million m^3/day)');
ylabel('Reservoir B release, Q2 (million m^3/day)');
title('Question 1: Optimal Water Allocation');
legend('Objective function contours','Demand boundary: Q1 + Q2 = 10', 'Optimal solution','Location', 'best');
grid on;
hold off;
