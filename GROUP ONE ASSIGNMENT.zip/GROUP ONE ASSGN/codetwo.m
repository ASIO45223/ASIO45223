 
clc;
clear;
close all;
 
% 1. Define the negative-benefit objective function
objective = @(x) -(80*x(1) - 2*x(1)^2+ 60*x(2) - 1.5*x(2)^2);
 
% 2. Define the linear constraints A*x <= b
A = [4 3;1 1];      
b = [100;30];
 
% 3. Define lower and upper bounds
lb = [0 0];
ub = [20 25];
 
% 4. Choose an initial feasible solution
x0 = [10 10];
 
% 5. Set optimisation options
options = optimoptions('fmincon','Algorithm', 'sqp','Display', 'iter');
 
% 6. Solve the optimisation problem
[x_opt, negative_Bmax, exitflag, output] = fmincon( ...
    objective, x0, A, b, [], [], lb, ub, [], options);
 
% Convert the minimum negative benefit to maximum benefit
B_max = -negative_Bmax;
 
% 7. Calculate resource use
water_used = 4*x_opt(1) + 3*x_opt(2);
land_used = sum(x_opt);
 
% 8. Display the results
fprintf('\nQUESTION 2: IRRIGATION ALLOCATION\n');
fprintf('Area allocated to Crop A (x1) = %.4f hectares\n', x_opt(1));
fprintf('Area allocated to Crop B (x2) = %.4f hectares\n', x_opt(2));
fprintf('Water used = %.4f units\n', water_used);
fprintf('Land used = %.4f hectares\n', land_used);
fprintf('Maximum agricultural benefit = %.4f benefit units\n', B_max);
fprintf('Solver exit flag = %d\n', exitflag);
 
% 9. Plot the optimal land allocation
figure;
bar(x_opt);
set(gca, 'XTick', 1:2, 'XTickLabel', {'Crop A', 'Crop B'});
ylabel('Land allocated (hectares)');
title('Question 2: Optimal Irrigation Land Allocation');
grid on;
 
% 10. Plot the objective function contours and feasible boundaries
[x1_grid, x2_grid] = meshgrid(0:0.2:20, 0:0.2:25);
Benefit = 80*x1_grid - 2*x1_grid.^2+ 60*x2_grid - 1.5*x2_grid.^2;
 
figure;
contourf(x1_grid, x2_grid, Benefit, 25);
colorbar;
hold on;
 
% Plot water and land constraint boundaries
x1_line = linspace(0, 20, 200);
plot(x1_line, (100 - 4*x1_line)/3, 'r--', 'LineWidth', 2);
plot(x1_line, 30 - x1_line, 'w-', 'LineWidth', 2);
 
% Mark the optimal solution
plot(x_opt(1), x_opt(2), 'kp','MarkerSize', 13, 'MarkerFaceColor', 'y');
 
xlabel('Area of Crop A, x1 (hectares)');
ylabel('Area of Crop B, x2 (hectares)');
title('Question 2: Irrigation Benefit and Feasible Region');
legend('Agricultural benefit contours','Water constraint boundary','Land constraint boundary','Optimal solution', 'Location', 'best');
grid on;
hold off;
