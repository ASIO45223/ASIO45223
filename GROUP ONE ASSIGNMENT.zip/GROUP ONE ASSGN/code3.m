 
clc;
clear;
close all;
 
% 1. Define the energy-cost objective function
objective = @(q) 0.8*q(1)^2 + 1.1*q(2)^2 + 0.3*q(1)*q(2);
 
% 2. Define linear constraints A*q <= b
% q1 + q2 >= 12 becomes -q1 - q2 <= -12
A = [-1 -1;0.6 0.8];
b = [-12;10.5];
 
% 3. Define lower and upper pumping limits
lb = [0 0];
ub = [8 9];
 
% 4. Choose an initial feasible solution
q0 = [7 5];
 
% 5. Set optimisation options
options = optimoptions('fmincon','Algorithm', 'sqp','Display', 'iter');
 
% 6. Solve the optimisation problem
[q_opt, E_min, exitflag, output] = fmincon(objective, q0, A, b, [], [], lb, ub, [], options);
 
% 7. Calculate total pumping and drawdown index
total_pumping = sum(q_opt);
drawdown_index = 0.6*q_opt(1) + 0.8*q_opt(2);
 
% 8. Display the results
fprintf('\nQUESTION 3: GROUNDWATER PUMPING OPTIMISATION\n');
fprintf('Pumping rate from Borehole A (q1) = %.4f\n', q_opt(1));
fprintf('Pumping rate from Borehole B (q2) = %.4f\n', q_opt(2));
fprintf('Total groundwater pumped = %.4f\n', total_pumping);
fprintf('Drawdown index = %.4f (maximum allowed = 10.5)\n', drawdown_index);
fprintf('Minimum energy cost = %.4f energy-cost units\n', E_min);
fprintf('Solver exit flag = %d\n', exitflag);
 
% 9. Plot optimal pumping rates
figure;
bar(q_opt);
set(gca, 'XTick', 1:2,'XTickLabel', {'Borehole A', 'Borehole B'});
ylabel('Pumping rate (model flow units)');
title('Question 3: Optimal Groundwater Pumping Rates');
grid on;
 
% 10. Plot objective-function contours and constraint boundaries
[q1_grid, q2_grid] = meshgrid(0:0.1:8, 0:0.1:9);
Energy = 0.8*q1_grid.^2 + 1.1*q2_grid.^2+ 0.3*q1_grid.*q2_grid;
 
figure;
contourf(q1_grid, q2_grid, Energy, 25);
colorbar;
hold on;
 
q1_line = linspace(0, 8, 200);
 
% Water demand boundary: q1 + q2 = 12
plot(q1_line, 12 - q1_line, 'r--', 'LineWidth', 2);
 
% Drawdown boundary: 0.6*q1 + 0.8*q2 = 10.5
plot(q1_line, (10.5 - 0.6*q1_line)/0.8,'w-', 'LineWidth', 2);
 
% Mark the optimal solution
plot(q_opt(1), q_opt(2), 'kp','MarkerSize', 13, 'MarkerFaceColor', 'y');
 
xlabel('Borehole A pumping rate, q1');
ylabel('Borehole B pumping rate, q2');
title('Question 3: Groundwater Pumping Optimisation');
legend('Energy-cost contours','Water demand boundary', 'Drawdown boundary', 'Optimal solution', 'Location', 'best');
grid on;
hold off;
